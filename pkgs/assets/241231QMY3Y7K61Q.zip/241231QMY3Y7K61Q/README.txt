
┌┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┐
├┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┤
├─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┤
│ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │
├─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┤
│ │ │ │ │ │ │ │ │ │U│.│S│.│ │G│R│A│P│H│I│C│S│ │C│O│M│P│A│N│Y│ │ │ │ │ │ │ │ │ │
├─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┤
│ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │
├─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┤
├─────────────────────────────────────────────────────────────────────────────┤
│                                 ~~ INFO ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ TYPEFACE     │ TX-02 Berkeley Mono™ Typeface Family                         │
│ VERSION      │ 2.002                                                        │
│ RELEASED ON  │ 2024-12-31                                                   │
│ TICKET No.   │ 9JMJ7W8P                                                     │
│ BUILD DATE   │ 2024-12-31 19:04:56 UTC                                      │
│ FONT COUNT   │ 4 Fonts                                                      │
│ GLYPH COUNT  │ 2576 Glyphs                                                  │
│ BUILD TIME   │ 9.12 seconds                                                 │
│ SERVICE No.  │ 8L769727NV                                                   │
│ SERVICE      │ TS-024 Berkeley Mono™ Standard Compiler                      │
│ SERVICE TIER │ STANDARD                                                     │
│ LICENSE No.  │ 16OK-JJ2Q-3373-KP84                                          │
│ LICENSE      │ LT-02 Developer Font License                                 │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ FONTS ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ TX-02-772M   │ Regular                                                      │
│ TX-02-774M   │ Oblique                                                      │
│ TX-02-7B2M   │ Bold                                                         │
│ TX-02-7B4M   │ Bold Oblique                                                 │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                         ~~ BUILD SPECIFICATIONS ~~                          │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ FC-001       │ 7                                                            │
│ FC-002       │ 7B                                                           │
│ FC-003       │ 24                                                           │
│ FC-004       │ zero.slashed                                                 │
│ FC-005       │ seven.standard                                               │
│ FC-008       │ off                                                          │
│ FC-010       │ desktop_otf                                                  │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ FILES ~~                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│ TX-02-Regular.otf                                                           │
│ TX-02-Oblique.otf                                                           │
│ TX-02-Bold.otf                                                              │
│ TX-02-Bold-Oblique.otf                                                      │
│ README.txt                                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                         ~~ LOGS (2024-12-31 UTC) ~~                         │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ 19:04:47.860 │ INIT: Querying database for build ticket information         │
│ 19:04:47.863 │ INIT: Generated Package ID: 241231QMY3Y7K61Q                 │
│ 19:04:47.863 │ INIT: Loading static font compiler                           │
│ 19:04:47.864 │ FEATURES: Processing FC-010: Set OTF format                  │
│ 19:04:48.025 │ FEATURES: Processing FC-004: Target: zero, Source: zero.slas │
│ 19:04:48.026 │ FEATURES: Processing FC-005: Target: seven, Source: seven.st │
│ 19:04:51.014 │ INTERPOLATE: Regular                                         │
│ 19:04:51.617 │ INTERPOLATE: Oblique                                         │
│ 19:04:51.687 │ INTERPOLATE: Bold                                            │
│ 19:04:51.754 │ INTERPOLATE: BoldOblique                                     │
│ 19:04:52.433 │ INTERPOLATE: Interpolating 4 instances                       │
│ 19:04:52.437 │ COMPILE: OTF, TX-02-Regular                                  │
│ 19:04:53.462 │ DISK IO: Saving TX-02-Regular.otf to ramdisk                 │
│ 19:04:53.568 │ COMPILE: OTF, TX-02-Oblique                                  │
│ 19:04:54.611 │ DISK IO: Saving TX-02-Oblique.otf to ramdisk                 │
│ 19:04:54.726 │ COMPILE: OTF, TX-02-Bold                                     │
│ 19:04:55.733 │ DISK IO: Saving TX-02-Bold.otf to ramdisk                    │
│ 19:04:55.838 │ COMPILE: OTF, TX-02-BoldOblique                              │
│ 19:04:56.861 │ DISK IO: Saving TX-02-Bold-Oblique.otf to ramdisk            │
│ 19:04:56.977 │ PACKAGE: Compressing font package 241231QMY3Y7K61Q.zip       │
│ 19:04:56.977 │ PACKAGE: Uploading font package to AWS S3                    │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ LEGAL ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ COPYRIGHT    │ Copyright 2022-2024. All Rights Reserved.                    │
│              │ Intellectual Property of U.S. Graphics, LLC.                 │
├─────────────────────────────────────────────────────────────────────────────┤
├┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┤
└┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┘